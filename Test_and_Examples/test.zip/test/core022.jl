int main() {
    int x;
    double y;
    printInt(x);
    printDouble(y);
    return 0;
}
