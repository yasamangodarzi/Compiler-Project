/* allow comparing booleans. */

int main() {
  if (true == true) { printInt(42); }
  return 0 ;

}