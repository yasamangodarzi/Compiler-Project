int main() {
    if (true) {
      printInt(1);
      return 0;
    }
}