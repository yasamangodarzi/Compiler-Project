int main() {
    int x;

    x = 5;
    while (x > 0) {
        printInt(x);
        x--;
    }

    printInt(x);
    
    return 0;
}
    
